/// <reference path="./lib/Intellisense/js-turtle_hy.ts" />
//DOCUMENTATION: https://hanumanum.github.io/js-turtle/
/*
showGrid(20);      
forward(distance)  
right(angle)       
left(angle) 	   
goto(x,y) 	       
clear() 	       
penup() 	       
pendown() 	       
reset() 	       
angle(angle)	   
width(width)       

color(r,g,b)
color([r,g,b])
color("red")
color("#ff0000")



//Einzelner Regentropfen

let dropstart = 260
let dropend = -351
let currentdropY = dropstart
color("Blue")


function raindrop(){

    if(currentdropY <= dropend){
        currentdropY = dropstart;
    }

setTimeout(() => {
    clear()
    width(2)
    goto(0, currentdropY)
    forward(8)
    currentdropY -= 25;
    loop = requestAnimationFrame(raindrop)
}, 200)

}

//function splash(){

setTimeout(() => {
    clear()
    color("blue")
    width(3)
    goto(-20, -180)
    left(20)
    forward(10)
    right(20)
    goto(-15, -180)
    forward(10)
    goto(-10, -180)
    right(20)
    forward(10)
    splash = requestAnimationFrame(splash)
}, 200)

//}


let loop = requestAnimationFrame(raindrop)
let splash = requestAnimationFrame(splash)


//Wasseranimation:
/*
let geradeX = 700;
let winkel = 90;
let schrittweite = 5;

let waterfill;

color("blue");
width(2); 
speed(0); 

goto(0, 0); 
setheading(0,0)
 


function waterfill() {

    if (geradeX <= 0) {
        cancelAnimationFrame(waterfill); 
        return; 
    }

    forward(geradeX);
    left(winkel); 
    geradeX = geradeX - schrittweite; 
    
   animationFrameId = requestAnimationFrame(waterfill);
}


waterfill();
*/



/*


let dropstart = 250; 
let dropend = -351;
let dropSpeed = 30;
let COLUMNS = 3; 
let ROWS = 1;
let COLUMN_SPACING = 120;
let ROW_SPACING = 100;
let START_X = -COLUMN_SPACING; 
let allDrops = [];
let loop;
let SPLASH_DURATION = 3; 

// Variablen für die Füll-Animation
let i = 0;
let maxLines = 150; 
let LINE_WIDTH = 1000; 
let LINE_HEIGHT = 5; 
let FILL_START_X = -500; 
let FILL_START_Y = -500; 

let fillSpeedFactor = 15; 
let frameCount = 0; 

color("Blue");
width(2);

function splash(drop) {
    if (drop.splashCounter >= SPLASH_DURATION) {
        return;
    }
    color("blue");
    width(3);
    let impactY = dropend + 5;
    goto(drop.x - 20, impactY);
    forward(10);
    goto(drop.x, impactY);
    forward(15);
    goto(drop.x + 20, impactY);
    forward(10);
    drop.splashCounter++;
}

function combinedAnimation() {
    clear(); 
    drawFillStep();
    drawRainStep();
    frameCount++; 
    loop = requestAnimationFrame(combinedAnimation);
}

function drawFillStep() {

    if (frameCount % fillSpeedFactor !== 0) {
        return; 
    }

    if (i < maxLines) {
        width(LINE_HEIGHT); 
        color("blue");
        let currentY = FILL_START_Y + (i * LINE_HEIGHT); 

        penup();
        goto(FILL_START_X, currentY); 
        
        left(90);
        left(90);
        left(90);
        left(90); 

        pendown();
        forward(LINE_WIDTH); 

        i++; 
    }
}

function drawRainStep() {
    color("blue");
    width(2);
    
    for (let k = 0; k < allDrops.length; k++) {
        let drop = allDrops[k];
        if (drop.y <= dropend) {
            drop.y = dropstart + (k % ROWS * ROW_SPACING); 
            drop.splashCounter = 1; 
        }
        penup();
        goto(drop.x, drop.y);
        pendown(); 
        forward(15); 
        if (drop.splashCounter > 0) {
            splash(drop);
        }
        drop.y -= dropSpeed;
    }
}

function initDrops() {
    for (let c = 0; c < COLUMNS; c++) {
        for (let r = 0; r < ROWS; r++) { 
            allDrops.push({
                x: START_X + (c * COLUMN_SPACING),
                y: dropstart + (r * ROW_SPACING),
                splashCounter: 0
            });
        }
    }
}

initDrops(); 
loop = requestAnimationFrame(combinedAnimation);

/*
forward(1)
left(2)

for(i = 0; i < 180; i++){
    forward(1)
    left(1)
    
} */

    /*

function fill(){    W

goto(350, -350)
color("blue")
width(8)
setSpeed(70)

for(i = 0; i < 500; i++){
    left(90)
    forward(700)
    right(90)
    forward(5)
    right(90)
    forward(700)
    left(90)
    forward(5)

}
}

fill()

*/








/*
let fillSpeedFactor = 30;


let dropstart = 250; 
let dropend = -351;
let COLUMNS = 3; 
let ROWS = 1;
let COLUMN_SPACING = 80;
let ROW_SPACING = 100;
let START_X = -COLUMN_SPACING; 
let allDrops = [];
let loop;
let SPLASH_DURATION = 3; 


let fillLineCounter = 0;
let maxFillLines = 80;
let FILL_START_X = 350;
let FILL_START_Y = -350; 
let FILL_LINE_LENGTH = 700; 
let FILL_SPACING = 5; 

let frameCount = 0; 

let dropSpeed = 30;
color("Blue");
width(2);

function splash(drop) {
    if (drop.splashCounter >= SPLASH_DURATION) {
        return;
    }
    
    // ZWINGE die Turtle zu einer HORIZONTALEN Ausrichtung für Splashes
    right(90); 
    
    color("blue");
    width(3);
    let impactY = dropend + 5;
    
    // Die Splash-Linien
    penup();
    goto(drop.x - 20, impactY);
    pendown();
    forward(10);
    
    penup();
    goto(drop.x, impactY);
    pendown();
    forward(15);
    
    penup();
    goto(drop.x + 20, impactY);
    pendown();
    forward(10);
    
    // ZWINGE die Turtle zurück auf die SENKRECHTE Ausrichtung
    left(90); 
    
    drop.splashCounter++;
}

function combinedAnimation() {
    clear(); 
    
    redrawFill(); 
    drawFillStep(); 
    drawRainStep();
    
    frameCount++; 
    loop = requestAnimationFrame(combinedAnimation);
}

// Zeichnet die Füllung VOM ANFANG bis zum aktuellen Zählerstand neu
function redrawFill() {
    // Definieren Sie die Linienbreite als Konstante
    const LINE_WIDTH = 8;
    // Setze die Sprungweite auf 7, um eine leichte Überlappung zu erzwingen (schließt die Lücken)
    const JUMP_DISTANCE = 7; 
    
    color("blue");
    width(LINE_WIDTH);
    
    for (let i = 0; i < fillLineCounter; i++) {
        
        // <<< KORREKTUR: Sprungweite mit leichtem Überlappungsfaktor setzen >>>
        let currentY = FILL_START_Y + (i * JUMP_DISTANCE); 
        
        // Positioniere am linken Rand
        penup();
        goto(FILL_START_X, currentY); 
        pendown();
        
        // Setze Ausrichtung auf HORIZONTAL (z.B. 90 Grad nach rechts)
        right(90); 
        
        // Zeichne von links nach rechts
        forward(FILL_LINE_LENGTH);
        
        // Gehe ohne Zeichnen zur nächsten Position
        penup();
    }
}


function drawFillStep() {
    if (fillLineCounter >= maxFillLines || frameCount % fillSpeedFactor !== 0) {
        return; 
    }
    let currentY = FILL_START_Y + (fillLineCounter * FILL_SPACING * 2);

    color("blue");
    width(8);
    
    penup();
    goto(FILL_START_X, currentY);
    pendown(); 
    left(90);
    forward(FILL_LINE_LENGTH);
    right(90); 
    forward(FILL_SPACING);
    right(90);
    forward(FILL_LINE_LENGTH);
    left(90);
    forward(FILL_SPACING);
    fillLineCounter++; 
}

function drawRainStep() {
    // KRITISCHER FIX: Setze die Ausrichtung der Turtle auf SENKRECHT (nach unten)
    penup();
    goto(0, 0); 
    right(90); 
    right(90); 
    
    color("blue");
    width(2);
    
    for (let k = 0; k < allDrops.length; k++) {
        let drop = allDrops[k];
        
        if (drop.y <= dropend) {
            drop.y = dropstart + (k % ROWS * ROW_SPACING); 
            drop.splashCounter = 1; 
        }
        
        // Zeichne den Tropfen (fällt dank Ausrichtungskorrektur senkrecht)
        penup();
        goto(drop.x, drop.y);
        pendown(); 
        forward(15); 
        
        if (drop.splashCounter > 0) {
            splash(drop);
        }
        
        drop.y -= dropSpeed;
    }
}

function initDrops() {
    for (let c = 0; c < COLUMNS; c++) {
        for (let r = 0; r < ROWS; r++) { 
            allDrops.push({
                x: START_X + (c * COLUMN_SPACING),
                y: dropstart + (r * ROW_SPACING),
                splashCounter: 0
            });
        }
    }
}

initDrops(); 
loop = requestAnimationFrame(combinedAnimation);







/*
let dropSpeed = 30;
let fillSpeedFactor = 30;


let dropstart = 250; 
let dropend = -351;
let COLUMNS = 3; 
let ROWS = 1;
let COLUMN_SPACING = 80;
let ROW_SPACING = 100;
let START_X = -COLUMN_SPACING; 
let allDrops = [];
let loop;
let SPLASH_DURATION = 3; 


let fillLineCounter = 0;
let maxFillLines = 80;
let FILL_START_X = 350;
let FILL_START_Y = -350; 
let FILL_LINE_LENGTH = 700; 
let FILL_SPACING = 5; 

let frameCount = 0; 

color("Blue");
width(2);

function splash(drop) {
    if (drop.splashCounter >= SPLASH_DURATION) {
        return;
    }
    color("blue");
    width(3);
    let impactY = dropend + 5;
    goto(drop.x - 20, impactY);
    forward(10);
    goto(drop.x, impactY);
    forward(15);
    goto(drop.x + 20, impactY);
    forward(10);
    drop.splashCounter++;
}

function combinedAnimation() {
    
    drawFillStep();
    drawRainStep();
    frameCount++; 
    loop = requestAnimationFrame(combinedAnimation);
}

function drawFillStep() {
    if (fillLineCounter >= maxFillLines || frameCount % fillSpeedFactor !== 0) {
        return; 
    }
    let currentY = FILL_START_Y + (fillLineCounter * FILL_SPACING * 2);

    color("blue");
    width(8);
    
    penup();
    goto(FILL_START_X, currentY);
    pendown(); 
    left(90);
    forward(FILL_LINE_LENGTH);
    right(90); 
    forward(FILL_SPACING);
    right(90);
    forward(FILL_LINE_LENGTH);
    left(90);
    forward(FILL_SPACING);
    fillLineCounter++; 
}

function drawRainStep() {
    color("blue");
    width(2);
    
    for (let k = 0; k < allDrops.length; k++) {
        let drop = allDrops[k];
        if (drop.y <= dropend) {
            drop.y = dropstart + (k % ROWS * ROW_SPACING); 
            drop.splashCounter = 1; 
        }
        penup();
        goto(drop.x, drop.y);
        pendown(); 
        forward(15); 
        if (drop.splashCounter > 0) {
            splash(drop);
        }
        drop.y -= dropSpeed;
    }
}

function initDrops() {
    for (let c = 0; c < COLUMNS; c++) {
        for (let r = 0; r < ROWS; r++) { 
            allDrops.push({
                x: START_X + (c * COLUMN_SPACING),
                y: dropstart + (r * ROW_SPACING),
                splashCounter: 0
            });
        }
    }
}

initDrops(); 
loop = requestAnimationFrame(combinedAnimation);

*/